/*
This file is used to create and istablished the connection with express server.

*/
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const multer  = require('multer');

const app = express();

const port=3300;
app.listen(port, function () {
  console.log('server running on :' + port);
})

//routs

// admin routs
const Itemapi = require('./server/routes/itemapi');
const Empapi = require('./server/routes/employeeapi');
const Userapi = require('./server/routes/userapi');

// for use body parser to urlencode and read json
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({'extended':true}));
// for use current directory with join dist
app.use(express.static(path.join(__dirname, 'dist')));
app.use('/uploads', express.static('uploads'));

//use cors
app.use(cors());

// use api route

app.use('/itemapi', Itemapi);
app.use('/employeeapi', Empapi);
app.use('/userapi', Userapi);


app.get('*', function(req, res, next) {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
});
 
// mongo connection
const mongoose = require('mongoose');

//mongo connection to database
mongoose.Promise =  global.Promise;
mongoose.connect('mongodb://localhost/testExp')
  .then(() =>  console.log('connection succesfully done'))
  .catch((err) => console.error(err));

