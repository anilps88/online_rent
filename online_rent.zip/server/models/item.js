const mongoose= require('mongoose');

const ItemSchema =mongoose.Schema({
	name:{
		type:String
	},
	rent_price:{
		type:String
	},
	manufacture_date:{
		type:String
	},
	actual_cost:{
		type:String
	} 
}); 

const Item= module.exports = mongoose.model('items',ItemSchema);