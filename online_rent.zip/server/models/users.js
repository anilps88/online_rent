
const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
  name: {
    type: String
  },
  email: {
    type: String
  },
  password: {
    type: String
  },
  date_added: {
    type: String
  }
});

const User = module.exports = mongoose.model('users', UserSchema);