const mongoose= require('mongoose');

const EmployeeSchema =mongoose.Schema({
	name:{
		type:String
	},
	email:{
		type:String
	},
	mobile:{
		type:Number
	},
	designation:{
		type:String
	},
	address:{
		type:String
	},
	profile:{
		type:String
	},
	addedDate:{
		type:String
	}
}); 

const Employee= module.exports = mongoose.model('employees',EmployeeSchema);