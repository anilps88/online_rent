const express = require('express');
const router = express.Router();

const mongoose = require('mongoose');

const Item = require('../models/item.js');

var multer  = require('multer')


router.get('/', function (req, res, next) {
	res.send('yes It worksss..');
});

/* img */

var img = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/emp-imgs');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + file.originalname);
    }
});

var upload = multer({ storage: img }).single('profile');

router.post('/uploadImage', function (req, res, next) {
    upload(req, res, function (err) {
        if (err) {
            return res.status(501).json({ error: err });
        }
        return res.json({ uploadname: req.file.filename });

    });
});

//fetch all records record 
router.get("/getAllItems", (req, res, next) => {

	Item.find().exec(function (err, emp) {
		res.json(emp);

	});
});

router.post('/additem', function (req, res, next) {

	Item.findOne({ email: req.body.email }).exec(function (err, result) {
		if (result) {
			res.json(0);
		}
		else {
			let date = new Date().toISOString().split('T')[0];

			let newItem = new Item({
				name: req.body.name,
				rent_price: req.body.rent_price,
				manufacture_date: req.body.manufacture_date,
				actual_cost: req.body.actual_cost 
			});

			newItem.save((err, Admin) => {
				if (err) {
					res.json({ msg: 'Something went wrong' });
				}
				else {

					res.json({ msg: 'Added Sucessfully', 'user': Admin });
				}

			});
		}
	});


});

router.delete('/deleteItm/:id', function (req, res, next) {
	Item.findByIdAndRemove(req.params.id, req.body, function (err, post) {
		if (err) return next(err);
		res.json({ msg: 'Record Deleted', status: 1 });
	});
});

router.get("/getItem/:id", (req, res, next) => {

	Item.findById(req.params.id, function (err, result) {
		if (result) {
			res.json(result);
		}
		else {
			res.json(0);
		}
	});
});

router.post("/update-item", (req, res, next) => {

	Item.findById(req.body.id, function (err, result) {
		if (result) {

				result.name = req.body.name,
				result.rent_price = req.body.rent_price,
				result.manufacture_date = req.body.manufacture_date,
				result.actual_cost = req.body.actual_cost, 

				// Save the updated document back to the database
				result.save(function (err, result) {
					if (err) {
						res.json({ msg: 'Something went wrong', status: 0 });
					}
					res.json({ msg: 'Information Updated Sucessfully', status: 1 });
				});

		}
		else {
			res.status(500).send(err);
		}
	});
});


module.exports = router;