const express = require('express');
const router = express.Router();

const mongoose = require('mongoose');
var md5 = require('md5');

const User = require('../models/users.js');


router.get('/', function (req, res, next) {
	res.send('yes It worksss..');
});


router.post("/login", (req, res, next) => {
	var pass = md5( req.body.password);
	console.log(pass)
	User.findOne({ email: req.body.email, password: pass })
		.exec(function (err, resData) {
			if (resData) {
				res.json({ status: 1, user: resData });
			}
			else {
				res.json({ status: 0 });
			}
		});
});

// add new user entry to database
router.post('/adduser', function (req, res, next) {

	User.findOne({ email: req.body.email }).exec(function (err, result) {
		if (result) {
			res.json(0);
		}
		else {
			let date = new Date().toISOString().split('T')[0];

			let newUser = new User({
				name: req.body.name,
				email: req.body.email,
				password: md5(req.body.password),
				date_added: date
			});

			newUser.save((err, User) => {
				if (err) {
					res.json({ msg: 'Something went wrong' });
				}
				else {
					res.json({ msg: 'New user Added Sucessfully', 'user': User });
				}
			});
		}
	})


});



module.exports = router;