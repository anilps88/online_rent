import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EditItemComponent } from './edit-item/edit-item.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { ItemsComponent } from './items/items.component';

export const AppRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'employees', component: EmployeesComponent },
    { path: 'edit-employee/:id', component: EditEmployeeComponent },
    { path: 'items', component: ItemsComponent },
    { path: 'edit-item/:id', component: EditItemComponent },
    { path: '', redirectTo: 'login', pathMatch: 'full'}
];
 
export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);