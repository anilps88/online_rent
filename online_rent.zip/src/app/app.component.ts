import { Component } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators,PatternValidator } from '@angular/forms';
import { LocalStorage } from '@ngx-pwa/local-storage';
import * as $ from 'jquery';
import { PathServiceService } from './path-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  UserInfo:any;
  checkUser: Subscription;

  constructor(private router:Router, private localStorage:LocalStorage,private route: ActivatedRoute, private http:HttpClient,public webservicesURL:PathServiceService ){}

  ngOnInit() {
    this.localStorage.getItem('logged').subscribe((User)=>{
      if(User){
        this.UserInfo = User;
      }
    });
    this.checkUserlogin();
  }

  checkUserlogin(){
    this.checkUser = this.webservicesURL.userlogin$.subscribe((res)=>{
      this.UserInfo = res;
    });
  }

  logout() {
    this.localStorage.removeItem('logged').subscribe(() => { }, () => { });
    this.UserInfo = null;
    this.router.navigateByUrl('login');
  }
}
