import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PathServiceService } from '../path-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators,PatternValidator } from '@angular/forms';
import { LocalStorage } from '@ngx-pwa/local-storage';
import * as $ from 'jquery';

@Component({
  selector: 'app-edit-item',
  templateUrl: './edit-item.component.html',
  styleUrls: ['./edit-item.component.css']
})
export class EditItemComponent implements OnInit {

  constructor(private router:Router, private localStorage:LocalStorage,private route: ActivatedRoute, private http:HttpClient,public webservicesURL:PathServiceService ){}

  serviceURL =  this.webservicesURL.webServicePath;

  id = this.route.snapshot.paramMap.get('id');
  loggedInuser:any;
  itemFrom:any;
  image:any;

  itemDetails:any;

  ngOnInit() {
    this.localStorage.getItem('logged').subscribe((User)=>{
      if(User){
        this.loggedInuser = User._id;
      }
      else{
        this.router.navigateByUrl('login');
      }
    });

    this.createItmForm();
    this.getitemDetails();
  }

  createItmForm() {
    this.itemFrom = new FormGroup({
      id: new FormControl(this.id),
      name: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]), 
      rent_price: new FormControl('', [Validators.required]),
      manufacture_date: new FormControl('', [Validators.required]),
      actual_cost: new FormControl('', [Validators.required, Validators.minLength(10), Validators.pattern('^[0-9]+$')]), 
    })
  }

  editItm(){
    this.http.post(this.serviceURL + '/itemapi/update-item', this.itemFrom.value)
    .subscribe(res=>{
      $('#alerts').html('Item Updated Successfully');
        $('#alerts').css('display', 'block');
        setTimeout(() => {
          $('#alerts').css('display', 'none');
        }, 3000);
        this.itemFrom.reset();
        this.itemFrom.markAsPristine();
    },(err)=>{
      console.log(err);
    })
  }

  getitemDetails(){
    this.http.get(this.serviceURL + '/itemapi/getItem/'+this.id)
    .subscribe(res=>{
      this.itemDetails = res;

      this.itemFrom.patchValue({
        name:  this.itemDetails.name,
        rent_price:  this.itemDetails.rent_price,
        manufacture_date:  this.itemDetails.manufacture_date,
        actual_cost:  this.itemDetails.actual_cost, 
      });
      this.image = this.itemDetails.profile;
    },(err)=>{
      console.log(err);
    })
  }


    /*  image upload */
    imgUpload(fileInput: any) {
      let image = fileInput.target.files;
  
      const formData: any = new FormData();
      const files: Array<File> = image;
  
      var ext = files[0].name.match(/\.(.+)$/)[1].toLowerCase();
      var size = files[0].size / 1024;
      
      if(size < 2048){
  
        if (ext === 'jpg' || ext === 'jpeg' || ext === 'png') {
  
          formData.append("profile", files[0], files[0]['name']);
          this.http.post(this.serviceURL + '/itemapi/uploadImage', formData)
            .subscribe(res => {
              let profileImage = res['uploadname'];
              if (profileImage) {
                this.itemFrom.patchValue({
                  profile: profileImage
                });
                this.image = profileImage;
              }
    
            }, (err) => {
              console.log(err);
            }
            );
        } else {
          $('#alertd').css('display', 'block');
          $('#alertd').html('Please select image .jpeg, .jpg, png');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 5000);
        }
      }
      else{
        $('#alertd').css('display', 'block');
        $('#alertd').html('File size exeeded (File size must be less than 2 MB)');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 5000);
      }
    }

}
