import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ROUTING } from './app.routing';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalStorageModule } from '@ngx-pwa/local-storage';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { PathServiceService } from './path-service.service';
import { EmployeesComponent } from './employees/employees.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { ItemsComponent } from './items/items.component';
import { EditItemComponent } from './edit-item/edit-item.component';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EmployeesComponent,
    EditEmployeeComponent,
    ItemsComponent,
    EditItemComponent
  ],
  imports: [
    BrowserModule,
    ROUTING,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    LocalStorageModule,
    NgxPaginationModule
  ],
  providers: [PathServiceService,{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
